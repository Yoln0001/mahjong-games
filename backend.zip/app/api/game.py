# _*_ coding : utf-8 _*_
# @Time : 2026/1/24 21:44
# @Author : Yoln
# @File : game
# @Project : mahjong-handle-web
from __future__ import annotations

from fastapi import APIRouter

from ..domain import UserProgress, evaluate_guess
from .deps import log, repo
from .schemas import ApiError, ApiResponse, GuessReq, ResetReq, StartReq

router = APIRouter()

# -----------------------------
# Hint format helpers
# -----------------------------

# 依据你上传的 zip 项目生成逻辑：末尾两位数字 1~4 对应 东南西北
# round wind code: round + 1
# seat wind code : ((4 + winner - oya) % 4) + 1
_WIND_MAP = {1: "东", 2: "南", 3: "西", 4: "北"}


def _strip_tip_prefix(tip: str) -> str:
    """
    将类似 '提示: Tanyao' / '提示：断幺' 去掉前缀，返回役名本体。
    不做任何中英映射（按你的要求：直接使用返回名字）。
    """
    if not tip:
        return ""
    for sep in ("提示:", "提示："):
        if tip.startswith(sep):
            return tip[len(sep):].strip()
    return tip.strip()


def _split_includes_from_han_tip(han_tip: str) -> tuple[str, list[str]]:
    """
    从 '3番30符 3000点 (包括立直,自摸)' 解析出：
      main='3番30符 3000点'
      includes=['立直','自摸']
    若格式不匹配，返回 (原串, [])。
    """
    if not han_tip:
        return "", []

    l = han_tip.find("(")
    r = han_tip.rfind(")")
    if l == -1 or r == -1 or r <= l:
        return han_tip.strip(), []

    main = han_tip[:l].strip()
    bracket = han_tip[l + 1:r].strip().replace("，", ",")

    # 期望 bracket: '包括立直,自摸'
    if bracket.startswith("包括"):
        items = [x.strip() for x in bracket[len("包括"):].split(",") if x.strip()]
        return main, items

    return han_tip.strip(), []


def _remove_tsumo_from_han_tip(han_tip: str) -> tuple[str, bool]:
    """
    将 hanTip 括号里的 '自摸' 移除，并单独返回 is_tsumo 标记：
      输入:  '... (包括立直,自摸)'
      输出: ('... (包括立直)', True)

    若括号里只有自摸，移除后直接返回 main（不保留空括号）。
    若无法解析括号，则兜底：只判断是否含'自摸'，并尽量不改动原文。
    """
    if not han_tip:
        return "", False

    main, includes = _split_includes_from_han_tip(han_tip)
    if not includes:
        # 无括号/无法解析时兜底
        return han_tip.strip(), ("自摸" in han_tip)

    is_tsumo = "自摸" in includes
    new_includes = [x for x in includes if x != "自摸"]

    if not new_includes:
        return main, is_tsumo

    return f"{main} (包括{','.join(new_includes)})", is_tsumo


def _hand_raw_from_obj(hand_obj) -> str:
    """
    尽量从 hand 对象中找到题库原始字符串，用于解析末尾两位风码。
    兼容多个可能的字段名，避免你后端结构微调导致接口失效。
    """
    if hand_obj is None:
        return ""

    if isinstance(hand_obj, str):
        return hand_obj

    for attr in ("raw", "raw_str", "hand_str", "source", "answer", "origin", "text", "hand"):
        v = getattr(hand_obj, attr, None)
        if isinstance(v, str) and v:
            return v

    return ""


def _parse_winds_from_hand_raw(hand_raw: str) -> tuple[int | None, int | None]:
    """
    按 zip 项目的 hands 格式：最后两位数字是 +{round+1}{seat+1}
    例如末尾 '23' => 场风=2(南), 自风=3(西)
    """
    if not hand_raw or len(hand_raw) < 2:
        return None, None

    suffix = hand_raw[-2:]
    if not suffix.isdigit():
        return None, None

    round_code = int(suffix[0])
    seat_code = int(suffix[1])
    return round_code, seat_code


def _wind_tip_from_codes(round_code: int | None, seat_code: int | None) -> str:
    seat = _WIND_MAP.get(seat_code, "未知")
    rnd = _WIND_MAP.get(round_code, "未知")
    return f"自风：{seat}，场风：{rnd}"


def _infer_is_tsumo_from_hand_raw(hand_raw: str) -> bool | None:
    """
    zip 项目中 hand_string 的拼接规则：
      tsumo:  hand + machi + '+{winds}'  => '+' 总数通常为 1
      ron  :  hand + '+' + machi + '+{winds}' => '+' 总数通常为 2

    因此可用 '+' 个数做推断：
      count('+') == 1 => 自摸
      count('+') >= 2 => 荣和
    若 hand_raw 为空或无法推断，返回 None。
    """
    if not hand_raw:
        return None
    plus_count = hand_raw.count("+")
    if plus_count == 1:
        return True
    if plus_count >= 2:
        return False
    return None


def _is_tsumo_text(is_tsumo: bool) -> str:
    return "自摸" if is_tsumo else "荣和"


def _build_hint(tip: str, han_tip: str, hand_obj) -> dict:
    """
    构造你要求的新 hint 格式：
      {
        "yakuTip": "...",
        "hanTip": "... (包括立直)",   # 括号内不含自摸
        "windTip": "自风：南，场风：南",
        "isTsumo": "自摸" / "荣和"
      }
    """
    yaku_tip = _strip_tip_prefix(tip)

    new_han_tip, is_tsumo_from_han = _remove_tsumo_from_han_tip(han_tip)

    hand_raw = _hand_raw_from_obj(hand_obj)
    round_code, seat_code = _parse_winds_from_hand_raw(hand_raw)
    wind_tip = _wind_tip_from_codes(round_code, seat_code)

    is_tsumo_from_raw = _infer_is_tsumo_from_hand_raw(hand_raw)
    # 优先使用 hand_raw 推断（与 zip 的编码逻辑一致），推断不了再用 han_tip 兜底
    is_tsumo = is_tsumo_from_raw if is_tsumo_from_raw is not None else is_tsumo_from_han

    return {
        "yakuTip": yaku_tip,
        "hanTip": new_han_tip,
        "windTip": wind_tip,
        "isTsumo": _is_tsumo_text(bool(is_tsumo)),
    }


def _ensure_user(game, user_id: str) -> bool:
    """Ensure user progress exists.

    IMPORTANT: must be called inside ``repo.update`` so that state is written back.
    """
    game.users.setdefault(user_id, UserProgress())
    return True


@router.post("/game/start", response_model=ApiResponse)
def start_game(req: StartReq) -> ApiResponse:
    g = repo.create(hand_index=req.handIndex, max_guess=req.maxGuess)

    # 这里修改 users，必须写回：用 update 强制写回
    repo.update(g.game_id, lambda game: _ensure_user(game, req.userId))

    log.info("game_start gameId=%s userId=%s maxGuess=%s", g.game_id, req.userId, g.max_guess)

    return ApiResponse(
        ok=True,
        data={
            "gameId": g.game_id,
            "maxGuess": g.max_guess,
            "createdAt": g.created_at,
            # 关键：hint 改为新结构
            "hint": _build_hint(tip=g.hand.tip, han_tip=g.hand.han_tip, hand_obj=g.hand),
        },
        error=None,
    )


@router.post("/game/{game_id}/guess", response_model=ApiResponse)
def guess(game_id: str, req: GuessReq) -> ApiResponse:
    try:
        def updater(game):
            return evaluate_guess(game=game, user_id=req.userId, guess_str=req.guess)

        ok, err = repo.update(game_id, updater)
    except KeyError:
        return ApiResponse(ok=False, data=None, error=ApiError(code="GAME_NOT_FOUND", message="gameId 不存在"))

    if err:
        log.info(
            "guess_invalid gameId=%s userId=%s code=%s",
            game_id,
            req.userId,
            err.code.value,
        )
        return ApiResponse(
            ok=False,
            data=None,
            error=ApiError(code=err.code.value, message=err.message, detail=err.detail),
        )

    assert ok is not None

    # 为了拿到 hand_raw（解析风向/自摸），这里读取一次游戏对象
    g = repo.get(game_id)

    # 关键日志：成功提交
    log.info(
        "guess_ok gameId=%s userId=%s remain=%s finish=%s win=%s",
        game_id,
        req.userId,
        ok.remain,
        ok.finish,
        ok.win,
    )

    return ApiResponse(
        ok=True,
        data={
            "guessTiles14": ok.guess_tiles_14,
            "colors14": ok.colors_14,
            "remain": ok.remain,
            "finish": ok.finish,
            "win": ok.win,
            # 关键：hint 改为新结构（tip/hanTip 用本次计算结果，风向/自摸从题目 hand 上解析）
            "hint": _build_hint(
                tip=ok.tip,
                han_tip=ok.han_tip,
                hand_obj=(g.hand if g else None),
            ),
        },
        error=None,
    )


@router.get("/game/{game_id}/status", response_model=ApiResponse)
def status(game_id: str, userId: str) -> ApiResponse:
    g = repo.get(game_id)
    if not g:
        return ApiResponse(ok=False, data=None, error=ApiError(code="GAME_NOT_FOUND", message="gameId 不存在"))

    p = g.users.get(userId)
    if not p:
        return ApiResponse(
            ok=True,
            data={
                "gameId": g.game_id,
                "maxGuess": g.max_guess,
                "hitCountValid": 0,
                "remain": g.max_guess,
                "finish": False,
                "win": False,
                "history": [],
                # 关键：hint 改为新结构
                "hint": _build_hint(tip=g.hand.tip, han_tip=g.hand.han_tip, hand_obj=g.hand),
            },
        )

    history = [
        {"guessTiles14": e.guess_tiles_14, "colors14": e.colors_14, "createdAt": e.created_at}
        for e in p.history
    ]

    return ApiResponse(
        ok=True,
        data={
            "gameId": g.game_id,
            "maxGuess": g.max_guess,
            "hitCountValid": p.hit_count_valid,
            "remain": max(g.max_guess - p.hit_count_valid, 0),
            "finish": p.finished,
            "win": p.win,
            "history": history,
            # 关键：hint 改为新结构
            "hint": _build_hint(tip=g.hand.tip, han_tip=g.hand.han_tip, hand_obj=g.hand),
        },
    )


@router.post("/game/{game_id}/reset", response_model=ApiResponse)
def reset(game_id: str, req: ResetReq) -> ApiResponse:
    repo.delete(game_id)
    g = repo.create(hand_index=req.handIndex, max_guess=req.maxGuess)

    repo.update(g.game_id, lambda game: _ensure_user(game, req.userId))

    log.info("game_reset oldGameId=%s newGameId=%s userId=%s", game_id, g.game_id, req.userId)

    return ApiResponse(ok=True, data={"gameId": g.game_id, "maxGuess": g.max_guess, "createdAt": g.created_at})
