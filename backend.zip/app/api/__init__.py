# _*_ coding : utf-8 _*_
# @Time : 2026/1/24 21:40
# @Author : Yoln
# @File : __init__.py
# @Project : mahjong-handle-web
"""
API package.

Expose the aggregated FastAPI router as ``router``.
"""

from .router import router

__all__ = ["router"]
